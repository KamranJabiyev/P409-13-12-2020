﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Notification
    {
        internal string message;
        protected internal int count;
        private protected string title;
    }

    internal class SmsNotify: Notification
    {
        public SmsNotify()
        {
            message = "Salam";
            count = 1;
            title = "Salamlama";
            Console.WriteLine(count);
            Console.WriteLine(title);
        }
    }

    public class Test
    {
        public Test()
        {
            Notification notification = new Notification();
            notification.count = 10;
            //notification.title = "";
            Console.WriteLine(notification.count);
        }
    }
}
