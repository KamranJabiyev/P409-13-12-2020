﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoNS;
using DemoNS.NestedNS;

namespace AccessModifiers
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Access Modifiers

            #region Public - field,method,property - class
            //Car car = new Car("BMW", "X6", 20000);
            //car.Brand = "Mercedes";
            //car.Test();
            //Console.WriteLine(car.Brand);
            #endregion

            #region Private - all class members(method,field,property)
            //Car car = new Car("BMW", "X6", 20000, 300);
            //car.SetSpeed(450);
            //Console.WriteLine(car.GetSpeed());
            //car.Speed = 150;
            //Console.WriteLine(car.Speed);
            #endregion

            #region Protected - all class members
            //Car car = new Car("Mercedes", "Sclass", 10000,300);
            //car.HorsePower = 400;
            //Console.WriteLine(car.HorsePower);
            #endregion

            #region Public readonly - field
            //Car car = new Car("BMW", "X5", 15000, 300, "Black");
            //Console.WriteLine(car.Color);
            #endregion

            #region Private readonly - field
            //Car car = new Car("BMW","X5",15000,300,"Red");
            //Console.WriteLine(car.CarDetail());
            #endregion

            #region Internal - all class member - class
            //Notification n = new Notification();

            #endregion

            #region Protected internal - all class members
            //First part(protected) -for others referenced project
            // Second part(internal) -for same project
            //Notification n = new Notification();
            #endregion

            #region Private protected - all class members
            //First part(Private) -for others referenced project
            // Second part(protected) -for same project

            #endregion
            #endregion

            #region Namespace
            Student student = new Student();
            DemoNS.Person person = new DemoNS.Person();
            Person p = new Person();
            Test1 t = new Test1();
            Console.WriteLine();
            #endregion
        }
    }

    #region Namespace
    class Person
    {
        public int P1 { get; set; }
    }
    #endregion

    #region Access modifiers
    //class Test : Notification
    //{
    //    public Test()
    //    {
    //        count = 100;
    //        //title = "";
    //        Console.WriteLine(count);
    //    }
    //}
    #endregion

}
