﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoNS
{
    class Person
    {
        public int P2 { get; set; }
    }

    class Test1
    {

    }
}

namespace DemoNS.NestedNS
{
    class Student { }
}
